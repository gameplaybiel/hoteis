package br.project.Hoteis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoteisApplicationTests {

	@Test
	void contextLoads() {
	}

}
